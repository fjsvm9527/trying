import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
import argparse
import json
import os
import sys
import logging
import glob
import re
import joblib
import random
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
def load_feature_config(json_path, all_train_columns,side):
    """
    读取分组配置，并将特征名转换为对应的列索引
    """
    # 1. 读取 JSON
    with open(json_path, 'r') as f:
        group_config = json.load(f) # 得到 {'Expert_1': ['f1_bp', ...], ...}
    

    # 2. 建立映射表: 特征名 -> 索引 (例如 'f1_bp' -> 0)
    # 这一步极其重要，Tensor切片需要整数索引
    feat_to_idx = {name: i for i, name in enumerate(all_train_columns)}
    
    # 3. 转换: 将每个Expert下的特征名列表，变成索引列表
    group_indices = []
    
    # 确保按 Expert_1, Expert_2... 顺序读取，防止字典乱序
    sorted_keys = sorted(group_config.keys()) 
    
    for expert_name in sorted_keys:
        feature_names = group_config[expert_name]
        if side=='buy':
            feature_names = [feature+'bp' for feature in feature_names]
        else:
            feature_names = [feature+'ap' for feature in feature_names]
        # 查找对应的索引
        indices = [feat_to_idx[name] for name in feature_names if name in feat_to_idx]
        
        if len(indices) == 0:
            print(f"警告: {expert_name} 没有匹配到任何特征！")
            
        group_indices.append(indices)
        print(f"已加载 {expert_name}: 包含 {len(indices)} 个特征")
        
    return group_indices
def seed_everything(seed: int = 42):
    """
    设置全局随机种子，保证结果可复现
    """
    # 1. Python 原生
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed) # 禁止 hash 随机化

    # 2. Numpy
    np.random.seed(seed)

    # 3. PyTorch (CPU & GPU)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # 如果使用多 GPU

    # 4. 保证 CuDNN 确定性 (会对性能有轻微影响)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    print(f"Global seed set to {seed}")
def create_timestamp_fast(df, date_col='ExchActionDay', 
                         time_col='ExchUpdateTime', 
                         millisec_col='ExchUpdateMillisec'):
    df['date_part'] = pd.to_datetime(df[date_col].astype(str), format='%Y%m%d')
    def time_to_seconds(time_str):
        if isinstance(time_str, str):
            parts = time_str.split(':')
            if len(parts) == 3:  # HH:MM:SS
                h, m, s = map(int, parts)
                return h * 3600 + m * 60 + s
            elif len(parts) == 2:  # HH:MM
                h, m = map(int, parts)
                return h * 3600 + m * 60
        return 0
    df['time_seconds'] = df[time_col].apply(time_to_seconds)
    df['millisec_seconds'] = df[millisec_col] / 1000.0
    df['total_seconds'] = df['time_seconds'] + df['millisec_seconds']
    df['timestamp'] = df['date_part'] + pd.to_timedelta(df['total_seconds'], unit='s')
    temp_cols = ['date_part', 'time_seconds', 'millisec_seconds', 'total_seconds']
    df = df.drop(columns=temp_cols)
    df = df.sort_values('timestamp').reset_index(drop=True)
    return
def load_aligned_data(npz_path, gate_dir, ap_indices, bp_indices, target_code):
    try:
        basename = os.path.basename(npz_path)
        date_str = ''.join(filter(str.isdigit, basename))
        search_pattern = os.path.join(gate_dir, f"{date_str}*_gate.parquet")
        import glob
        gate_files = glob.glob(search_pattern)
        if not gate_files:
            logging.warning(f"No gate file found for date {date_str}, skipping.")
            return None, None, None, None   
        gate_path = gate_files[0]
        with np.load(npz_path, allow_pickle=True) as d:
            raw_feats = d['features']
            raw_labels = d['labels']
            sites = d['sites']
            timestamps = d['timestamps'] if 'timestamps' in d else d['hms']
        df_gate = pd.read_parquet(gate_path)
        df_npz_idx = pd.DataFrame({
            'timestamp': timestamps,
            'orig_idx': np.arange(len(timestamps))
        })
        # 保证门控网络特征和因子时间戳对齐
        df_npz_idx['timestamp'] = pd.to_datetime(df_npz_idx['timestamp'])
        df_gate['timestamp'] = pd.to_datetime(df_gate['timestamp'])
        merged_df = pd.merge(df_npz_idx, df_gate, on='timestamp', how='inner')
        # print(merged_df)
        if len(merged_df) == 0:
            logging.warning(f"No overlapping data for {date_str}.")
            return None, None, None, None
        valid_indices = merged_df['orig_idx'].values
        if target_code == 1: # AP
            aligned_feats = raw_feats[valid_indices][:, ap_indices]
        elif target_code == 2: # BP
            aligned_feats = raw_feats[valid_indices][:, bp_indices]
        else:
            raise ValueError("Invalid target_code")
            
        aligned_labels = raw_labels[valid_indices]
        aligned_sites = sites[valid_indices]
        
        # 提取门控特征
        gate_cols = ['depth','rv_5','range','l5_imbalance','oi_change','trade_intensity','trend','spread','gate_session_decay','gate_open_impulse']
        aligned_indicators = merged_df[gate_cols].values.astype(np.float32)
        feats_tensor = torch.from_numpy(aligned_feats).float()
        labels_tensor = torch.from_numpy(aligned_labels).float()
        sites_tensor = aligned_sites # numpy array
        indicators_tensor = torch.from_numpy(aligned_indicators).float()

        return feats_tensor, labels_tensor, sites_tensor, indicators_tensor

    except Exception as e:
        logging.error(f"Error processing {npz_path}: {e}")
        return None, None, None, None

class SelectedIndicesDataset(torch.utils.data.Dataset):
    def __init__(self, features, indicators, labels, sites, target_code, seq_len, dilation=1):
        """
        新增 indicators 参数: (N, 12)
        """
        self.features = features
        self.indicators = indicators
        self.labels = labels
        self.seq_len = seq_len
        self.dilation = dilation
        self.span_offset = (seq_len - 1) * dilation
        
        valid_mask = (sites == target_code)
        all_indices = np.arange(len(sites))
        self.valid_anchors = all_indices[valid_mask & (all_indices >= self.span_offset)]
        
    def __len__(self):
        return len(self.valid_anchors)
    
    def __getitem__(self, idx):
        row_end = self.valid_anchors[idx]
        x_feat = self.features[row_end - self.span_offset : row_end + 1 : self.dilation]
        x_ind = self.indicators[row_end]
        y = self.labels[row_end]
        return x_feat, x_ind, y

def load_and_process_day(fpath, ap_indices, bp_indices, target_code):
    try:
        with np.load(fpath) as d:
            raw_feats = torch.from_numpy(d['features']) 
            raw_labels = torch.from_numpy(d['labels'])  
            sites = d['sites']
            
            if target_code == 1:
                target_feats = raw_feats[:, ap_indices]
            elif target_code == 2: 
                target_feats = raw_feats[:, bp_indices]
            else:
                raise ValueError(f"Unknown target_code: {target_code}")
            return target_feats, raw_labels, sites
            
    except Exception as e:
        logging.warning(f"Error loading {fpath}: {e}")
        return None, None, None

def setup_logging(save_dir):
    log_file = os.path.join(save_dir, 'run.log')
    root = logging.getLogger()
    if root.handlers:
        for handler in root.handlers:
            root.removeHandler(handler)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.FileHandler(log_file), logging.StreamHandler(sys.stdout)]
    )

def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_date_from_filename(filepath):
    match = re.search(r'(\d{8})', os.path.basename(filepath))
    return int(match.group(1)) if match else 0

class GRUPredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, dropout=0.2):
        super(GRUPredictor, self).__init__()
        self.gru = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        self.fc = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        out, _ = self.gru(x)
        out = self.fc(out[:, -1, :])
        return out
class MixerBlock(nn.Module):
    def __init__(self, seq_len, num_features, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(num_features)
        self.time_mlp = nn.Sequential(
            nn.Linear(seq_len, seq_len), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(seq_len, seq_len), nn.Dropout(dropout)
        )
        self.norm2 = nn.LayerNorm(num_features)
        self.channel_mlp = nn.Sequential(
            nn.Linear(num_features, num_features * 4), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(num_features * 4, num_features), nn.Dropout(dropout)
        )
    def forward(self, x):
        x = x + self.time_mlp(self.norm1(x).permute(0,2,1)).permute(0,2,1)
        x = x + self.channel_mlp(self.norm2(x))
        return x

class TimeMixerPredictor(nn.Module):
    def __init__(self, input_dim, seq_len, hidden_dim=64, num_layers=2, dropout=0.1, downsample_levels=2):
        super().__init__()
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.levels = downsample_levels + 1
        self.blocks = nn.ModuleList()
        curr_len = seq_len
        for _ in range(self.levels):
            self.blocks.append(nn.Sequential(*[MixerBlock(curr_len, hidden_dim, dropout) for _ in range(num_layers)]))
            curr_len //= 2
        self.downsample = nn.AvgPool1d(kernel_size=2, stride=2)
        self.head = nn.Linear(hidden_dim, 1)
        self.weights = nn.Parameter(torch.ones(self.levels) / self.levels)
    def forward(self, x):
        x = self.embedding(x)
        outputs = []
        for i in range(self.levels):
            x_out = self.blocks[i](x)
            outputs.append(x_out[:, -1, :])
            if i < self.levels - 1:
                x = self.downsample(x.permute(0, 2, 1)).permute(0, 2, 1)
        final = sum(o * w for o, w in zip(outputs, F.softmax(self.weights, dim=0)))
        return self.head(final)
import torch
import torch.nn as nn
class CCCLoss(nn.Module):
    """
    Lin's Concordance Correlation Coefficient (CCC) Loss.
    Loss = 1 - CCC
    
    CCC 衡量的是预测序列与真实序列在【均值】、【方差】和【相关性】上的综合一致度。
    范围 [-1, 1]，也就是 Loss 范围 [0, 2]。
    
    - 解决了 MSE 导致的"预测值坍缩为0"的问题 (因为方差差异会被惩罚)
    - 解决了 IC Loss 导致的"忽略数值绝对大小"的问题 (因为均值偏移会被惩罚)
    """
    def __init__(self, eps=1e-8):
        super(CCCLoss, self).__init__()
        self.eps = eps

    def forward(self, pred, target):
        # 1. 展平向量 (Batch 维度和序列维度合并，计算全局统计量)
        # 假设输入形状可能是 [Batch, Seq_Len] 或 [Batch, 1]
        pred_flat = pred.view(-1)
        target_flat = target.view(-1)
        
        # 2. 计算均值
        mean_pred = torch.mean(pred_flat)
        mean_target = torch.mean(target_flat)
        
        # 3. 计算方差 (使用 unbiased=False 对应公式中的总体方差，训练更稳定)
        var_pred = torch.var(pred_flat, unbiased=False)
        var_target = torch.var(target_flat, unbiased=False)
        
        # 4. 计算协方差
        # Cov = E[(x - ux)(y - uy)]
        covariance = torch.mean((pred_flat - mean_pred) * (target_flat - mean_target))
        
        # 5. 计算 CCC
        # 分子: 2 * Covariance
        numerator = 2 * covariance
        
        # 分母: var_pred + var_target + (mean_diff)^2
        # 这一步体现了 CCC 的精髓：它不仅要求相关(Cov大)，还要求方差一致(var项)，且均值一致(mean差项)
        denominator = var_pred + var_target + (mean_pred - mean_target)**2
        
        ccc = numerator / (denominator + self.eps)
        
        # 6. Loss = 1 - CCC
        # 我们希望 CCC 趋近于 1
        return 1.0 - ccc
class NativeLSTMPredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=2, dropout=0.1):
        super().__init__()
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        self.norm = nn.LayerNorm(hidden_dim)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = self.embedding(x)
        out, _ = self.lstm(x)
        last_step = out[:, -1, :]
        last_step = self.norm(last_step)
        return self.head(last_step)

import torch
import torch.nn as nn
import math

# --- JIT 加速的核心扫描算子 ---
@torch.jit.script
def slstm_scan_jit(
    i_gate: torch.Tensor, 
    f_gate: torch.Tensor, 
    z_gate: torch.Tensor, 
    o_gate: torch.Tensor,
    init_c: torch.Tensor, 
    init_n: torch.Tensor, 
    init_m: torch.Tensor
):
    B, T, H, D = i_gate.shape
    h_seq = []
    
    c_prev = init_c
    n_prev = init_n
    m_prev = init_m

    for t in range(T):
        i_t = i_gate[:, t]
        f_t = f_gate[:, t]
        z_t = z_gate[:, t]
        o_t = o_gate[:, t]
        m_t = torch.max(f_t + m_prev, i_t)
        
        i_prime = torch.exp(i_t - m_t)
        f_prime = torch.exp(f_t + m_prev - m_t)
        c_t = f_prime * c_prev + i_prime * z_t
        n_t = f_prime * n_prev + i_prime
        h_t = torch.sigmoid(o_t) * (c_t / (n_t + 1e-6))
        
        h_seq.append(h_t)
        c_prev = c_t
        n_prev = n_t
        m_prev = m_t

    return torch.stack(h_seq, dim=1)

class sLSTMBlock(nn.Module):
    def __init__(self, hidden_dim, num_heads=4, dropout=0.1):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        self.conv = nn.Conv1d(hidden_dim, hidden_dim, kernel_size=4, groups=hidden_dim, padding=3)
        self.conv_act = nn.SiLU()
        self.wx = nn.Linear(hidden_dim, 4 * hidden_dim)
        self.norm = nn.GroupNorm(num_heads, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        B, T, C = x.shape
        x_conv = x.permute(0, 2, 1)
        x_conv = self.conv(x_conv)[:, :, :T]
        x_conv = self.conv_act(x_conv)
        x_conv = x_conv.permute(0, 2, 1)
        gates = self.wx(x_conv) # (B, T, 4*H)
        gates = gates.view(B, T, 4, self.num_heads, self.head_dim)
        i_gate, f_gate, z_gate, o_gate = gates.unbind(dim=2)
        z_gate = torch.tanh(z_gate)
        init_c = torch.zeros(B, self.num_heads, self.head_dim, device=x.device)
        init_n = torch.ones(B, self.num_heads, self.head_dim, device=x.device)
        init_m = torch.zeros(B, self.num_heads, self.head_dim, device=x.device)
        h_out = slstm_scan_jit(i_gate, f_gate, z_gate, o_gate, init_c, init_n, init_m)
        h_out = h_out.reshape(B, T, C)
        h_out = h_out.permute(0, 2, 1)
        h_out = self.norm(h_out)
        h_out = h_out.permute(0, 2, 1)
        out = self.out_proj(h_out)
        return self.dropout(out) + x

# --- sLSTM 单元 ---
class sLSTMPredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=2, num_heads=4, dropout=0.1):
        super().__init__()
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.layers = nn.ModuleList([
            sLSTMBlock(hidden_dim, num_heads, dropout)
            for _ in range(num_layers)
        ])
        
        self.norm = nn.LayerNorm(hidden_dim)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = self.embedding(x)
        
        for layer in self.layers:
            x = layer(x)
            
        x = self.norm(x)
        return self.head(x[:, -1, :])

class sLSTM_Expert(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers=2, num_heads=4, dropout=0.1):
        super().__init__()
        # 每个 Expert 都有自己的 Embedding，负责将不同维度的 input 映射到统一的 hidden_dim
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.layers = nn.ModuleList([
            sLSTMBlock(hidden_dim, num_heads, dropout)
            for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        x = self.embedding(x)
        for layer in self.layers:
            x = layer(x)
        x = self.norm(x)
        return x[:, -1, :] # 取最后一个时间步

# --- 核心修改：基于特征分组的 MoE ---

class GroupedMoESLSTM(nn.Module):
    def __init__(self, 
                 feature_group_indices,  # list of list: [[0,1,5], [2,3], ...]
                 hidden_dim, 
                 indicator_dim, 
                 num_layers=2, 
                 dropout=0.1):
        super().__init__()
        
        self.feature_group_indices = feature_group_indices
        self.num_experts = len(feature_group_indices)
        
        # 1. 动态构建专家
        # 每个专家的 input_dim 等于该组特征的数量
        self.experts = nn.ModuleList()
        for group_indices in feature_group_indices:
            group_input_dim = len(group_indices)
            expert = sLSTM_Expert(
                input_dim=group_input_dim, 
                hidden_dim=hidden_dim,  # 所有专家输出维度统一，方便加权
                num_layers=num_layers,
                dropout=dropout
            )
            self.experts.append(expert)
        
        # 2. 路由网络 (保持不变)
        # 输入 Indicator，输出每个 Experts 的权重
        self.router = nn.Sequential(
            nn.Linear(indicator_dim, 64),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(64, self.num_experts),
            nn.Softmax(dim=-1)
        )

        # 3. 最终预测头
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, x_feat, x_ind):
        """
        x_feat: (Batch, Time, Total_Features) - 原始的大特征矩阵
        x_ind:  (Batch, Indicator_Dim) - 用于路由的指标数据
        """
        
        # --- A. 路由计算 ---
        # weights: (Batch, Num_Experts, 1)
        routing_weights = self.router(x_ind).unsqueeze(-1)
        
        # --- B. 专家并行计算 (特征切片) ---
        expert_outputs = []
        
        for i, expert in enumerate(self.experts):
            # 关键步骤：根据索引从大矩阵中切出该专家需要的特征
            # indices 必须是 tensor 或者是 list 才能用于切片
            indices = self.feature_group_indices[i]
            
            # x_feat[..., indices] 选取特征维度 (最后一维)
            # 结果形状: (Batch, Time, Group_Dim)
            x_group = x_feat[..., indices] 
            
            # 专家前向传播 -> (Batch, Hidden_Dim)
            out = expert(x_group)
            expert_outputs.append(out)

        expert_outputs = torch.stack(expert_outputs, dim=1)
        weighted_experts = routing_weights * expert_outputs
        final_hidden = torch.sum(weighted_experts, dim=1)
        
        return self.head(final_hidden)

def evaluate_model(model, test_files, config, scaler, col_config, device, threshold):
    model.eval()
    feature_cols = col_config['feature_cols']
    ap_indices = col_config['ap_indices']
    bp_indices = col_config['bp_indices']
    
    side = config['training'].get('side', 'buy')
    mode = 'bp' if side == 'buy' else 'ap'
    target_code = 1 if mode == 'ap' else 2
    target_label_col = 'label'
    gate_dir = config['paths']['gate_dir']
    # 需要计算收益的所有时间窗口
    horizon_cols = [
        'LABEL_CAL_DQ_inst1_1', 
        'LABEL_CAL_DQ_inst1_3', 
        'LABEL_CAL_DQ_inst1_5', 
        'LABEL_CAL_DQ_inst1_10', 
        'LABEL_CAL_DQ_inst1_15', 
        'LABEL_CAL_DQ_inst1_30', 
        'LABEL_CAL_DQ_inst1_60'
    ]
    gate_cols = ['depth','rv_5','range','l5_imbalance','oi_change','trade_intensity','trend','spread','gate_session_decay','gate_open_impulse']
    price_cols = ['ap1', 'bp1'] 
    ccc_stats = {
        'sum_pred': 0.0,
        'sum_target': 0.0,
        'sum_pred_sq': 0.0,   # pred^2
        'sum_target_sq': 0.0, # target^2
        'sum_prod': 0.0,      # pred * target
        'count': 0
    }
    total_rss = 0.0  
    sum_y_val = 0.0
    sum_y_sq_val = 0.0
    total_samples_mse = 0
    total_signal_count = 0
    horizon_accumulated_profit = {col: 0.0 for col in horizon_cols}

    for fpath in test_files:
        try:
            raw_req_cols = list(set(feature_cols + ['featSite','timestamp'] + price_cols + horizon_cols + [target_label_col]))
            df_raw = pd.read_parquet(fpath)
            create_timestamp_fast(df_raw)
            df_raw = df_raw[raw_req_cols]
            basename = os.path.basename(fpath)
            # 假设文件名格式类似 '20250425_SHFE_...'，提取 '20250425'
            date_str = basename.split('_')[1]
            # 寻找对应的 Gate 文件
            import glob
            gate_search = os.path.join(gate_dir, f"{date_str}*_gate.parquet")
            gate_files_found = glob.glob(gate_search)
            
            if not gate_files_found:
                logging.warning(f"Skipping {basename}: No matching gate file found.")
                continue

            df_gate = pd.read_parquet(gate_files_found[0])
            df_raw['timestamp'] = pd.to_datetime(df_raw['timestamp'])
            df_gate['timestamp'] = pd.to_datetime(df_gate['timestamp'])
            # print(df_raw['timestamp'].iloc[:10],df_gate['timestamp'].iloc[:10])
            df_merged = pd.merge(df_raw, df_gate, on='timestamp', how='inner')
            if len(df_merged) == 0:
                continue

            # === D. 现场特征处理 ===
            
            # 1. 提取原始因子并标准化
            feats_raw = df_merged[feature_cols].values
            feats_scaled = scaler.transform(feats_raw).astype(np.float32)
            
            N = len(df_merged)
            if mode == 'ap':
                feats_pure = feats_scaled[:, ap_indices]
            else:
                feats_pure = feats_scaled[:, bp_indices]
            indicators_pure = df_merged[gate_cols].values.astype(np.float32)
            feats_tensor = torch.from_numpy(feats_pure)      # (N, 409)
            indicators_tensor = torch.from_numpy(indicators_pure) # (N, 12)
            sites_str = df_merged['featSite'].astype(str).str.lower().values
            sites_code = np.zeros(N, dtype=np.int8)
            sites_code[sites_str == 'ap'] = 1
            sites_code[sites_str == 'bp'] = 2
            dummy_labels = torch.zeros(N) 
            dilation = config['training'].get('dilation', 1)
            ds = SelectedIndicesDataset(
                features=feats_tensor, 
                indicators=indicators_tensor,
                labels=dummy_labels, 
                sites=sites_code, 
                target_code=target_code, 
                seq_len=config['training']['seq_len'],
                dilation=dilation
            )
            
            if len(ds) == 0: continue
            loader = DataLoader(ds, batch_size=config['training']['batch_size'], shuffle=False, num_workers=0)
            
            # 5. 推理
            file_preds = []
            for x_feat, x_ind, _ in loader:
                    x_feat = x_feat.to(device)
                    x_ind = x_ind.to(device)
                    pred = model(x_feat, x_ind)
                    if pred.ndim == 0: pred = pred.unsqueeze(0)
                    file_preds.append(pred.detach().cpu().numpy())
            
            if not file_preds: continue
            all_preds  = np.concatenate(file_preds).ravel()
            valid_indices = ds.valid_anchors
            current_df_slice = df_merged.iloc[valid_indices].reset_index(drop=True)
            ap1_arr = current_df_slice['ap1'].values
            bp1_arr = current_df_slice['bp1'].values
            
            # --- Task A: 计算 MSE ---
            if target_label_col in current_df_slice.columns:
                y_true = current_df_slice[target_label_col].values
                batch_rss = np.sum((all_preds - y_true) ** 2)
                total_rss += batch_rss
                sum_y_val += np.sum(y_true)
                sum_y_sq_val += np.sum(y_true ** 2)
                p_flat = all_preds.astype(np.float64)
                t_flat = y_true.astype(np.float64)
                ccc_stats['count'] += len(p_flat)
                ccc_stats['sum_pred'] += np.sum(p_flat)
                ccc_stats['sum_target'] += np.sum(t_flat)
                ccc_stats['sum_pred_sq'] += np.sum(p_flat ** 2)
                ccc_stats['sum_target_sq'] += np.sum(t_flat ** 2)
                ccc_stats['sum_prod'] += np.sum(p_flat * t_flat)
                total_samples_mse += len(all_preds)
            
            # --- Task B: 计算多周期收益 ---
            # 信号逻辑：BP找极大值(>阈值)，AP找极小值(<阈值)
            signal_mask = all_preds > np.quantile(all_preds,0.9)
            count = np.sum(signal_mask)
            total_signal_count += count
            
            if count > 0:
                for h_col in horizon_cols:
                    if h_col not in current_df_slice.columns: continue
                    labels_arr = current_df_slice[h_col].values
                    
                    if mode == 'bp':
                        pnl = labels_arr[signal_mask] - ap1_arr[signal_mask]
                    else:
                        pnl = bp1_arr[signal_mask] - labels_arr[signal_mask]
                    
                    horizon_accumulated_profit[h_col] += np.sum(pnl)

        except Exception as e:
            logging.error(f"Error evaluating {fpath}: {e}")

    if total_samples_mse > 0:
        total_tss = sum_y_sq_val - (sum_y_val ** 2) / total_samples_mse
        if total_tss > 1e-9:
            final_r2 = 1 - (total_rss / total_tss)
        else:
            final_r2 = 0.0
        final_mse = total_rss / total_samples_mse
    else:
        final_r2 = -999.0
        final_mse = 999.0
    final_ccc_score = 0.0
    final_ccc_loss = 1.0
    if ccc_stats['count'] > 0:
        N = ccc_stats['count']
        mean_pred = ccc_stats['sum_pred'] / N
        mean_target = ccc_stats['sum_target'] / N
        
        # 计算总体方差 (Population Variance)
        # Var = E[X^2] - (E[X])^2
        var_pred = (ccc_stats['sum_pred_sq'] / N) - (mean_pred ** 2)
        var_target = (ccc_stats['sum_target_sq'] / N) - (mean_target ** 2)
        
        # 计算协方差
        # Cov = E[XY] - E[X]E[Y]
        cov = (ccc_stats['sum_prod'] / N) - (mean_pred * mean_target)
        
        # CCC 公式
        numerator = 2 * cov
        denominator = var_pred + var_target + (mean_pred - mean_target)**2
        
        if denominator > 1e-9:
            final_ccc_score = numerator / denominator
        else:
            final_ccc_score = 0.0
            
        final_ccc_loss = 1.0 - final_ccc_score
    log_msg = (f"Test Stats | Signals: {total_signal_count} | MSE: {final_mse:.6f} | R2: {final_r2:.6f} "
               f"| CCC Loss: {final_ccc_loss:.6f} (Score: {final_ccc_score:.6f})")
    
    total_profit = -np.inf
    sorted_horizons = sorted(horizon_cols, key=lambda x: int(x.split('_')[-1]))
    for h_col in sorted_horizons:
        short_name = h_col.split('_')[-1] + "s"
        
        if total_signal_count > 0:
            avg_p = horizon_accumulated_profit[h_col] / total_signal_count
            cur_profit = horizon_accumulated_profit[h_col]
        else:
            avg_p = 0.0
            cur_profit = 0.0
        if cur_profit>total_profit:
            total_profit = cur_profit
        log_msg += f" | {short_name}: {avg_p:.5f}"
    final_score = final_ccc_score
    logging.info(log_msg)
    # final_score = final_r2
    logging.info(f"(Profit: {final_score:.6f})")
    dist_msg = "Pred Dist | No Data"
    if True:
        p_mean = np.mean(all_preds)
        p_var = np.var(all_preds)
        p_75 = np.percentile(all_preds, 75)
        p_90 = np.percentile(all_preds, 90)
        p_95 = np.percentile(all_preds, 95) # 额外加一个95，参考用
        p_min = np.min(all_preds)
        p_max = np.max(all_preds)
        dist_msg = (f"Pred Dist | Mean: {p_mean:.5f} | Var: {p_var:.5f} | "
                    f"75%: {p_75:.5f} | 90%: {p_90:.5f} | 95%: {p_95:.5f} | "
                    f"Range: [{p_min:.3f}, {p_max:.3f}]")
    
    logging.info(dist_msg) # 打印分布信息
    return final_score


def train_pipeline(config, save_dir, device):
    side = config['training'].get('side', 'buy')
    mode = 'ap' if side == 'buy' else 'bp'
    target_code = 1 if mode == 'ap' else 2
    
    logging.info(f"Starting Training. Side: {side}")
    data_dir = config['paths']['processed_data_dir']
    gate_dir = config['paths']['gate_dir']
    all_files = sorted(glob.glob(os.path.join(data_dir, "day_*.npz")), key=get_date_from_filename)
    test_file_count = 14
    # train_files = all_files[:-test_file_count]
    train_files = all_files[:6]
    raw_data_dir = config['paths'].get('raw_data_dir', './merged_features_final')
    all_parquet = sorted(glob.glob(os.path.join(raw_data_dir, "*_features.parquet")), key=get_date_from_filename)
    # test_files_parquet = all_parquet[-test_file_count:] 
    test_files_parquet = all_parquet[-2:]
    col_indices_path = os.path.join(data_dir, 'col_indices.pkl')
    col_config = joblib.load(col_indices_path)
    scaler = joblib.load(os.path.join(data_dir, 'scaler.pkl'))
    ap_indices = torch.tensor(col_config['ap_indices'], dtype=torch.long)
    bp_indices = torch.tensor(col_config['bp_indices'], dtype=torch.long)
    if config['training']['side']=='buy':
        all_columns = [ col_config['feature_cols'][col] for col in col_config['bp_indices']]
    else:
        all_columns = [ col_config['feature_cols'][col] for col in col_config['ap_indices']]
    config_path = 'moe_feature_groups.json'
    print(all_columns)
    group_indices = load_feature_config(config_path, all_columns,config['training']['side'])
    model = GroupedMoESLSTM(
        feature_group_indices=group_indices,
        hidden_dim=config['model']['hidden_dim'],
        indicator_dim=10,
        num_layers=config['model']['num_layers'],
        # num_experts=config['model']['num_experts'],
        dropout=config['model']['dropout']
    ).to(device)
    # optimizer = optim.Adam(model.parameters(), lr=config['training']['learning_rate'])
    optimizer = optim.AdamW(model.parameters(), lr=config['training']['learning_rate'], weight_decay=1e-4)
    # criterion = nn.MSELoss()
    criterion = CCCLoss()
    best_model_path = os.path.join(save_dir, f"model_best_{side}.pth")
    best_test_profit = -np.inf

    # --- Training Loop ---
    logging.info(f"Training for {config['training']['epochs']} epochs...")
    
    for epoch in range(config['training']['epochs']):
        model.train()
        epoch_loss = 0
        total_batches = 0
        random.shuffle(train_files)
        
        for f_idx, fpath in enumerate(train_files):
            data_pack = load_aligned_data(fpath, gate_dir, ap_indices, bp_indices, target_code)
            if data_pack[0] is None: continue
            feats, labels, sites, indicators = data_pack
            dilation = config['training'].get('dilation', 1) 
            day_dataset = SelectedIndicesDataset(
                feats, indicators,labels, sites, target_code, 
                seq_len=config['training']['seq_len'], 
                dilation=dilation
            )
            if len(day_dataset) == 0: continue
                
            train_loader = DataLoader(day_dataset, batch_size=config['training']['batch_size'], shuffle=True, num_workers=0)
            
            day_loss = 0
            for x_feat, x_ind, y in train_loader:
                x_feat, x_ind, y = x_feat.to(device), x_ind.to(device), y.to(device)
                optimizer.zero_grad()
                pred = model(x_feat, x_ind).squeeze()
                loss = criterion(pred,y)
                loss.backward()
                # torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                day_loss += loss.item()
                total_batches += 1
            if (f_idx + 1) % 20 == 0:
                sys.stdout.write(f"\r[Epoch {epoch+1}] Day {f_idx+1}/{len(train_files)} | Loss: {day_loss/len(train_loader):.4f}")
                sys.stdout.flush()
            epoch_loss+=day_loss
        avg_epoch_loss = epoch_loss / total_batches if total_batches > 0 else 0
        print(f"\n>> Epoch {epoch+1} Train Loss: {avg_epoch_loss:.6f}")
        

        # --- Evaluation ---
        logging.info(f"Evaluating Epoch {epoch+1}...")
        current_profit = evaluate_model(model, test_files_parquet, config, scaler, col_config, device,threshold=1.0)
        
        logging.info(f">> Epoch {epoch+1} Test Avg Profit: {current_profit:.10f}")
        
        if current_profit > best_test_profit:
            best_test_profit = current_profit
            torch.save(model.state_dict(), best_model_path)
            logging.info(f"*** New Best Model Saved ***")

    return best_model_path

if __name__ == "__main__":
    seed_everything(42)
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True)
    args = parser.parse_args()
    
    config = load_config(args.config)
    save_dir = os.path.join(config['paths']['output_root'], config['experiment_name'])
    os.makedirs(save_dir, exist_ok=True)
    setup_logging(save_dir)
    
    # device = torch.device(f"cuda:{config['gpu']}" if torch.cuda.is_available() else "cpu")
    device = torch.device(f"cuda" if torch.cuda.is_available() else "cpu")
    train_pipeline(config, save_dir, device)